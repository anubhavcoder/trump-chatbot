# Import module MarkovChain from file cc_markov in markov_python folder.
# Import module time.
from markov_python.cc_markov import MarkovChain
import time

# Feed MarkovChain module all Trump's tweets.
mc = MarkovChain()
mc.add_file('data.txt')

# Welcome the user.
# Ask for the user's name.
name = raw_input('Welcome! Please sign your name here while we notify the President of your presence today. \nName: ')
time.sleep(2)
print 'It seems like Mr. President is in a good mood. You may talk to him for a while.'
print 'If anytime, you wish to leave the conversation, please enter "Bye".'
time.sleep(3)
print 'Please wait here for a second.'
time.sleep(7)
print 'Mr. President is ready to see you now.'
time.sleep(3)
print 'You may now speak to Mr. President.'

# Talk to the chatbot.
# Use a while loop so that the user can talk to the chatbot as long as they wish.
# The user can end the conversation by typing 'Bye' or 'bye', then the loop will break.
while True:
    talk = raw_input(name + ': ')
    list = mc.generate_text()
    str = ' '.join(list)
    if talk == 'Bye' or talk == 'bye':
        print 'Mr. President: Get your ass out of here.'
        break
    print 'Mr. President: ' + str
