# Import modules from twitter library to interact with Twitter API.
from twitter import Twitter, OAuth
# Enter token & secret for open authorization
ACCESS_TOKEN = '823627761445195780-sdNZTRfxoOllYZlvDdwuWNbWPAcWqM5'
ACCESS_SECRET = 'Fj7Tg1ZAXQwDurgxskwv9tzzwRBcB7UAlMAgJtip7umQ1'
COMSUMER_KEY = 'Jet1dbEyESoon9usNjODQ6tMu'
COMSUMER_SECRET = 'P9Eq178qZJV7wrikx0yClmtjLMb0p5FPrF827kIRxKgLnpmUAn'
oAuth = OAuth(ACCESS_TOKEN, ACCESS_SECRET, COMSUMER_KEY, COMSUMER_SECRET)
twitter = Twitter(auth=oAuth, retry = True)
    
# Fetch Trump's tweets in json foramt.
# Fetcched tweets will be returned chronologically, from the most recent to least recent tweets. 
# Only 200 tweets will be retrieved each time and each tweet comes with an unique ID.  
# Fetch the first 200 tweets (i.e., most recent 200 tweets) to extract a starting max_id. 
first_200_tweets = twitter.statuses.user_timeline(screen_name="realDonaldTrump", count = 200)
tweet_id_200 = first_200_tweets[199]["id"]
# Use a while loop with the starting max_id to fetch the rest of the tweets.
# The while loop will break when tweet_id_200 is out of range (i.e., no more tweets to fetch).
# Tweets will be stored into Trump_data.
# NOTE: due to Twitter's rate limit, only roughly the most recent 2500 tweets will be returned each time. 
Trump_data = []
while True:
    try:
        tweets_200 = twitter.statuses.user_timeline(screen_name="realDonaldTrump", count = 200, max_id = tweet_id_200)
        tweet_id_200 = tweets_200[199]["id"]
        for tweet in tweets_200:
            Trump_data.append(tweet)
    except:
        break
    
# Extract the content of the tweets and stored them in data.txt to feed the Markov Chain.
# The content of the tweets could be extracted from key "text."
text_data = "data.txt"
data_file = open(text_data, "w")
for line in Trump_data:
    text = line["text"]
    data_file.write(text.encode("utf-8"))
data_file.close()